namespace The_Wall.Models
{
    public abstract class BaseEntity
    {
        
    }
}