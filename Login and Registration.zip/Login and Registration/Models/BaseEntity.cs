namespace Login_and_Registration.Models
{
    public abstract class BaseEntity
    {
        
    }
}