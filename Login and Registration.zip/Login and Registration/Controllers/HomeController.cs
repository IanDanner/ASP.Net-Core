﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Login_and_Registration.Models;
using DbConnection;
using Microsoft.AspNetCore.Http;

namespace Login_and_Registration.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [Route("ValidUserRegisterModel/register")]
        public IActionResult Register(ValidUserRegisterModel user)
        {
            if(ModelState.IsValid)
            {
                List<Dictionary<string, object>> User = DbConnector.Query($"SELECT * FROM users WHERE email = '{user.Email}'");
                if(User.Count > 0){
                    ViewBag.error = "Email already registered";
                    return View("Index",user);
                }
                DbConnector.Query($"INSERT INTO users (firstName, lastName, email, password, created_at, updated_at) VALUES ('{user.FirstName}','{user.LastName}','{user.Email}','{user.Password}', NOW(), NOW())");
                ViewData["User"] = User;
                return View("Success");
            }
            return View("Index",user);
        }

        [HttpGet]
        [HttpPost]
        [Route("login")]
        public IActionResult Login(string email, string password)
        {
            if(email == null){
                ViewData["error"] = "No email input";
                return View("Index");
            }
            List<Dictionary<string, object>> User = DbConnector.Query($"SELECT * FROM users WHERE email = '{email}'");
            if(User.Count == 0){
                ViewData["error"] = "Email not registered";
                return View("Index");
            }
            foreach(var me in User){
                if((string)me["password"] != password){
                    ViewData["error"] = "Password is Incorrect";
                    return View("Index");
                }
            }
            ViewData["User"] = User;
            return View("Success");
        }
    }
}
